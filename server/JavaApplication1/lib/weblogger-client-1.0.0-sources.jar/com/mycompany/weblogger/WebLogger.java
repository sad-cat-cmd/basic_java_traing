package com.mycompany.weblogger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <h1>WebLogger Client</h1>
 * <p>
 * Асинхронный HTTP-клиент для взаимодействия с REST API логгирования WebLogger.
 * Предоставляет методы для инициализации процесса, отправки логов и остановки процесса
 * с автоматической обработкой таймаутов и потокобезопасностью.
 * </p>
 * 
 * <h2>Основные возможности:</h2>
 * <ul>
 *   <li>Инициализация процесса на сервере</li>
 *   <li>Отправка логов с таймаутом</li>
 *   <li>Остановка процесса</li>
 *   <li>Потокобезопасность через AtomicReference и синхронизацию</li>
 *   <li>Автоматическое управление ресурсами (AutoCloseable)</li>
 *   <li>Гибкая настройка таймаутов и URL</li>
 * </ul>
 * 
 * <h2>Пример использования:</h2>
 * <pre>
 * // Создание клиента с настройками по умолчанию
 * WebLogger logger = new WebLogger("admin@company.com", "billing-service");
 * 
 * try {
 *     // Инициализация процесса
 *     logger.initProcess();
 *     System.out.println("Process ID: " + logger.getIdProcess());
 *     
 *     // Отправка логов
 *     logger.sendLog(new SendedLog("INFO", "Service started"));
 *     logger.sendLog(new SendedLog("DEBUG", "Processing request #123"));
 *     logger.sendLog(new SendedLog("ERROR", "Database connection failed"));
 *     
 *     // Проверка состояния
 *     if (logger.isActive()) {
 *         System.out.println("Process is active");
 *     }
 *     System.out.println("Total logs sent: " + logger.getCountLogProcess());
 *     
 *     // Остановка процесса
 *     logger.stopProcess();
 *     System.out.println("Process stopped: " + logger.getStatusProcess());
 *     System.out.println("Finished at: " + logger.getTimeFinishProcess());
 *     
 * } catch (ExceptionLoggerWork e) {
 *     System.err.println("Error: " + e.getMessage());
 * }
 * </pre>
 * 
 * <h2>Конфигурация через конструктор:</h2>
 * <pre>
 * // Пользовательские настройки
 * WebLogger logger = new WebLogger(
 *     "http://custom-api-server.com/api",  // URL API
 *     "admin@company.com",                 // Владелец
 *     "billing-service",                   // Имя процесса
 *     Duration.ofSeconds(2),               // Таймаут подключения
 *     100                                  // Таймаут запроса в мс
 * );
 * </pre>
 * 
 * <h2>Использование с try-with-resources:</h2>
 * <pre>
 * try (WebLogger logger = new WebLogger("admin@company.com", "billing-service")) {
 *     logger.initProcess();
 *     logger.sendLog(new SendedLog("INFO", "Application started"));
 *     // Автоматический вызов close() при выходе из блока
 * }
 * </pre>
 * 
 * @author admin_
 * @version 2.0
 * @since 1.0
 * @see SendedLog
 * @see ExceptionLoggerWork
 */
public class WebLogger implements AutoCloseable {
    
    // ==================== КОНСТАНТЫ ====================
    
    /**
     * Базовый URL API по умолчанию.
     * Используется, если не указан другой URL в конструкторе.
     */
    public static String DEFAULT_API_BASE = "http://localhost:8080/api";
    
    /**
     * Таймаут подключения по умолчанию (1 секунда).
     * Применяется для установки TCP соединения с сервером.
     */
    public static Duration DEFAULT_CONNECT_TIMEOUT = Duration.ofSeconds(1);
    
    /**
     * Таймаут выполнения запроса по умолчанию (50 миллисекунд).
     * Применяется для ожидания ответа от сервера.
     */
    public static final long DEFAULT_REQUEST_TIMEOUT_MS = 50;
    
    /**
     * Максимальная длина имени процесса.
     * Используется при валидации входных параметров.
     */
    public static final int MAX_LENGTH_PROCESS_NAME = 50;
    
    /**
     * Максимальная длина имени владельца.
     * Используется при валидации входных параметров.
     */
    public static final int MAX_LENGTH_OWNER = 50;
    
    /**
     * HTTP статус 200 OK.
     * Используется для проверки успешности запроса.
     */
    public static final int RESPONSE_STATUS_CODE_OK = 200;
    
    /**
     * HTTP статус 201 Created.
     * Используется для проверки успешного создания процесса.
     */
    public static final int RESPONSE_STATUS_CODE_CREATED = 201;
    
    /**
     * ObjectMapper для работы с JSON.
     * Потокобезопасный и настроен на игнорирование неизвестных полей.
     */
    private static final ObjectMapper objectMapper = new ObjectMapper()
                                                        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    
    // ==================== ПОЛЯ ====================
    
    /**
     * Таймаут установки TCP соединения с сервером.
     */
    private final Duration connectTimeout;
    
    /**
     * Таймаут выполнения HTTP запроса в миллисекундах.
     * Если ответ не получен за это время, запрос прерывается.
     */
    private final long requestTimeoutMS;
    
    /**
     * Имя процесса.
     * Устанавливается при создании клиента и не может быть изменено.
     */
    private final String nameProcess;
    
    /**
     * Владелец процесса.
     * Устанавливается при создании клиента и не может быть изменено.
     */
    private final String owner;
    
    /**
     * Базовый URL API сервера.
     * Используется для формирования конечных точек API.
     */
    private final String apiUrl;
    
    /**
     * HTTP клиент для выполнения запросов к серверу.
     * Создается один раз при инициализации и используется для всех запросов.
     */
    private final HttpClient client;
    
    /**
     * Идентификатор процесса.
     * Устанавливается после успешной инициализации через {@link #initProcess()}.
     */
    private final AtomicReference<String> processId = new AtomicReference<>();
    
    /**
     * Секретный код для аутентификации запросов.
     * Устанавливается после успешной инициализации через {@link #initProcess()}.
     */
    private final AtomicReference<String> secureCode = new AtomicReference<>();
    
    /**
     * Время создания процесса в формате ISO-8601.
     * Устанавливается после успешной инициализации через {@link #initProcess()}.
     */
    private final AtomicReference<String> timeCreate = new AtomicReference<>();
    
    /**
     * Время завершения процесса в формате ISO-8601.
     * Устанавливается после успешной остановки через {@link #stopProcess()}.
     */
    private final AtomicReference<String> timeFinish = new AtomicReference<>();
    
    /**
     * Текущий статус процесса.
     * Возможные значения: "Active", "Running", "Stopped".
     */
    private final AtomicReference<String> statusProcess = new AtomicReference<>();
    
    /**
     * Общее количество успешно отправленных логов.
     * Автоматически обновляется после каждой успешной отправки.
     */
    private AtomicInteger countLog = new AtomicInteger(0);
    
    /**
     * Объект для синхронизации потоков.
     * Используется для обеспечения потокобезопасности критических секций.
     */
    private final Object lock = new Object();
    
    /**
     * URL для инициализации процесса.
     * Формат: {apiUrl}/process
     */
    private String pathInitProcess = null;
    
    /**
     * URL для остановки процесса.
     * Формат: {apiUrl}/process/{processId}/stop
     */
    private String pathStopProcess = null;
    
    /**
     * URL для отправки логов.
     * Формат: {apiUrl}/process/{processId}/logs
     */
    private String pathSendLog = null;
    
    /**
     * HTTP запрос для инициализации процесса.
     * Создается один раз и используется при вызове {@link #initProcess()}.
     */
    private HttpRequest requestInitProcess = null;
    
    /**
     * HTTP запрос для остановки процесса.
     * Создается после успешной инициализации и используется при вызове {@link #stopProcess()}.
     */
    private HttpRequest requestStopProcess = null;
    
    // ==================== ПРИВАТНЫЕ МЕТОДЫ ====================
    
    /**
     * Проверяет корректность входных данных для инициализации клиента.
     * 
     * <p>Валидируются следующие параметры:</p>
     * <ul>
     *   <li>Имя процесса - не null, не пустое, длина ≤ 50 символов</li>
     *   <li>Владелец - не null, не пустое, длина ≤ 50 символов</li>
     *   <li>URL API - если отличается от дефолтного, проверяется на null и пустоту</li>
     *   <li>Таймаут запроса - если отличается от дефолтного, проверяется > 0</li>
     * </ul>
     * 
     * @throws ExceptionLoggerWork если какой-либо параметр невалиден
     */
    private void isValidInData() throws ExceptionLoggerWork {
        if (nameProcess == null || nameProcess.isEmpty() ) {
            throw new ExceptionLoggerWork("Error init WebLogger:\n\tparam *nameProcess* is empty or null");
        }
        if (nameProcess.length() > MAX_LENGTH_PROCESS_NAME) {
            throw new ExceptionLoggerWork("Error init WebLogger:\n\tlength param *nameProcess* is more " + Integer.toString(WebLogger.MAX_LENGTH_PROCESS_NAME ));
        }
        if (owner == null || owner.isEmpty()) {
            throw new ExceptionLoggerWork("Error init WebLogger:\n\tparam *owner* is empty or null");
        }
        if (owner.length() > MAX_LENGTH_OWNER) {
            throw new ExceptionLoggerWork("Error init WebLogger:\n\tlength param *owner* is more " + Integer.toString(WebLogger.MAX_LENGTH_OWNER));
        }
        if (!apiUrl.equals(WebLogger.DEFAULT_API_BASE))  {
            if (apiUrl == null || apiUrl.isEmpty()) {
                throw new ExceptionLoggerWork("Error init WebLogger:\n\tparam *apiBaseApi* is empty or null");
            } 
        }
        if (this.requestTimeoutMS != WebLogger.DEFAULT_REQUEST_TIMEOUT_MS) {
            if (this.requestTimeoutMS <= 0) {
                throw new ExceptionLoggerWork("Error init WebLogger:\n\tparam *requestTimeoutMS* <= 0");
            }
        }
    }
    
    /**
     * Сериализует Map в JSON строку.
     * 
     * @param data   Map с данными для сериализации
     * @param excMsg Сообщение об ошибке для включения в исключение
     * @return JSON строка
     * @throws ExceptionLoggerWork если произошла ошибка сериализации
     */
    private String toJson(Map<String, Object> data,
                          String excMsg) throws ExceptionLoggerWork {
        try {
            return objectMapper.writeValueAsString(data);
        } catch (JsonProcessingException e) {
            if (excMsg == null || excMsg.isEmpty()) {
                throw new ExceptionLoggerWork("" + e.getMessage());
            }
            throw new ExceptionLoggerWork(excMsg + "failed to serialize JSON: " + e.getMessage());
        }
    }
    
    /**
     * Парсит JSON строку в Map с использованием TypeReference для сохранения типобезопасности.
     * 
     * @param json   JSON строка для парсинга
     * @param excMsg Сообщение об ошибке для включения в исключение
     * @return Map с данными из JSON
     * @throws ExceptionLoggerWork если JSON пустой или произошла ошибка парсинга
     */
    private Map<String, Object> fromJson(String json, String excMsg) throws ExceptionLoggerWork{
        if (json == null || json.isEmpty()) {
            if (excMsg == null) {
                throw new ExceptionLoggerWork("Response body is empty");
            }
            throw new ExceptionLoggerWork(excMsg + "Response body is empty");
        }
        try {
            return objectMapper.readValue(json, new TypeReference<Map<String, Object>>() {});
        } catch (JsonProcessingException e){
            if (excMsg == null) {
                throw new ExceptionLoggerWork("Failed to parse JSON: " +  e.getMessage() + "\nResponse: " + json);
            }
            throw new ExceptionLoggerWork(excMsg + 
                                          "Failed to parse JSON: " +  e.getMessage() + "\nResponse: " + json);
        }
    }

    /**
     * Безопасно извлекает строковое значение из Map по ключу.
     * 
     * @param map Map с данными
     * @param key Ключ для поиска
     * @return Значение в виде строки или null, если ключ отсутствует
     */
    private String getStringFromMap(Map<String, Object> map, String key) {
        Object value = map.get(key);
        if (value == null) {
            return null;
        }
        return value.toString();
    }
    
    /**
     * Безопасно извлекает целочисленное значение из Map по ключу.
     * 
     * @param map Map с данными
     * @param key Ключ для поиска
     * @return Целочисленное значение или -1, если ключ отсутствует или значение не число
     */
    private int getIntFromMap(Map<String, Object> map, String key) {
        Object value = map.get(key);
        if (value == null) return -1;
        try {
            if (value instanceof Number) {
                return ((Number) value).intValue();
            }
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /**
     * Парсит ответ от сервера при инициализации процесса.
     * 
     * <p>Ожидаемый JSON формат:</p>
     * <pre>
     * {
     *   "id": "proc_123",
     *   "access_code": "abc-123-def-456",
     *   "time_create": "2024-01-15T10:30:45",
     *   "status": "Active"
     * }
     * </pre>
     * 
     * <p>Обязательные поля:</p>
     * <ul>
     *   <li><b>id</b> - идентификатор процесса</li>
     *   <li><b>access_code</b> - секретный код для аутентификации</li>
     *   <li><b>time_create</b> - время создания процесса</li>
     *   <li><b>status</b> - статус процесса</li>
     * </ul>
     * 
     * @param responseBody JSON ответ от сервера
     * @throws ExceptionLoggerWork если ответ не содержит обязательные поля
     */
    private void parseInitProcessResponse(String responseBody) throws ExceptionLoggerWork{
        String excMsg ="Error with send request *init process*:\n\t";
        Map<String, Object> response = fromJson(responseBody, excMsg);
        String id = getStringFromMap(response, "id");
        
        String access_code = getStringFromMap(response, "access_code");
        String timeCreate = getStringFromMap(response, "time_create");
        String status = getStringFromMap(response, "status");
        if (id == null) {
            throw new ExceptionLoggerWork(excMsg + "Required field 'id' is missing in response");
        }
        if (access_code == null) {
            throw new ExceptionLoggerWork(excMsg + "Required field 'access_code' is missing in response");
        }
        if (timeCreate == null) {
            throw new ExceptionLoggerWork(excMsg + "Required field 'time_create' is missing in response");
        }
        if (status == null) {
            throw new ExceptionLoggerWork(excMsg + "Required field 'status' is missing in response");
        }
        this.processId.set(id);
        this.secureCode.set(access_code);
        this.timeCreate.set(timeCreate);
        this.statusProcess.set(status);
    }
    
    /**
     * Парсит ответ от сервера при остановке процесса.
     * 
     * <p>Ожидаемый JSON формат:</p>
     * <pre>
     * {
     *   "status": "Stopped",
     *   "time_finished": "2024-01-15T10:35:00"
     * }
     * </pre>
     * 
     * <p>Обязательные поля:</p>
     * <ul>
     *   <li><b>status</b> - статус процесса после остановки</li>
     *   <li><b>time_finished</b> - время завершения процесса</li>
     * </ul>
     * 
     * @param responseBody JSON ответ от сервера
     * @throws ExceptionLoggerWork если ответ не содержит обязательные поля
     */
    private void parseStopProcessResponse(String responseBody) throws ExceptionLoggerWork{
        String excMsg ="Error with send request *stop process*:\n\t";
        Map<String, Object> response = fromJson(responseBody, excMsg);
        String status = getStringFromMap(response, "status");
        String timeFinished = getStringFromMap(response, "time_finished");
        if (status == null) {
            throw new ExceptionLoggerWork(excMsg + "Required field 'status' is missing in response");
        }
        if (timeFinished == null) {
            throw new ExceptionLoggerWork(excMsg + "Required field 'time_finished' is missing in response");
        }
        this.statusProcess.set(status);
        this.timeFinish.set(timeFinished);
    }
    
    /**
     * Парсит ответ от сервера при отправке лога.
     * 
     * <p>Ожидаемый JSON формат:</p>
     * <pre>
     * {
     *   "number": 1
     * }
     * </pre>
     * 
     * <p>Обязательные поля:</p>
     * <ul>
     *   <li><b>number</b> - количество отправленных логов</li>
     * </ul>
     * 
     * @param responseBody JSON ответ от сервера
     * @throws ExceptionLoggerWork если ответ не содержит обязательные поля
     */
    private void parseSendLogResponse(String responseBody) throws ExceptionLoggerWork{
        String excMsg = "Error with send request *send log*:\n\t";
        Map<String, Object> response = fromJson(responseBody, excMsg);
        int logCount = getIntFromMap(response, "number");

        if (logCount == -1) {
            throw new ExceptionLoggerWork(excMsg + 
                "Required field 'number' or 'log_count' is missing in response");
        }
        
        this.countLog.set(logCount);
    }
    
    /**
     * Создает HTTP запрос для инициализации процесса.
     * 
     * <p>Запрос содержит JSON тело:</p>
     * <pre>
     * {
     *   "name": "{nameProcess}",
     *   "owner": "{owner}"
     * }
     * </pre>
     * 
     * @throws ExceptionLoggerWork если произошла ошибка сериализации JSON
     */
    private void createRequestInitProcess() throws ExceptionLoggerWork {
        String excMsg = "Error with send request *init process*:\n\t";
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("name", this.nameProcess);
        requestBody.put("owner", this.owner);
        String jsonBody;
        try {
            jsonBody = toJson(requestBody,
                     excMsg);
        } catch (ExceptionLoggerWork eLW) {
            throw eLW;
        }

        if (this.pathInitProcess == null) {
            this.createPathInitProcess();
        }
        HttpRequest newRequest = HttpRequest.newBuilder()
                                            .uri(URI.create(this.pathInitProcess))
                                            .header("Content-Type", "application/json")
                                            .POST(BodyPublishers.ofString(jsonBody))
                                            .build();
        this.requestInitProcess = newRequest;
    }
    
    /**
     * Создает HTTP запрос для остановки процесса.
     * 
     * <p>Запрос содержит JSON тело:</p>
     * <pre>
     * {
     *   "secureCode": "{secureCode}"
     * }
     * </pre>
     * 
     * @throws ExceptionLoggerWork если произошла ошибка сериализации JSON
     * @throws IllegalStateException если процесс не инициализирован
     */
    private void createRequestStopProcess() throws ExceptionLoggerWork {
        String excMsg = "Error with send request *stop process*:\n\t";
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("secureCode", this.secureCode.get());
        String jsonBody;
        try {
            jsonBody = toJson(requestBody,
                              excMsg);
        } catch (ExceptionLoggerWork eLW) {
            throw eLW;
        }

        if (this.pathStopProcess == null) {
            this.createPathStopProcess();
        }
        HttpRequest newRequest = HttpRequest.newBuilder()
                                            .uri(URI.create(this.pathStopProcess))
                                            .header("Content-Type", "application/json")
                                            .PUT(BodyPublishers.ofString(jsonBody))
                                            .build();
        this.requestStopProcess = newRequest;
    }
    
    /**
     * Создает HTTP запрос для отправки лога.
     * 
     * <p>Запрос содержит JSON тело:</p>
     * <pre>
     * {
     *   "secureCode": "{secureCode}",
     *   "status": "{status}",
     *   "info": "{info}"
     * }
     * </pre>
     * 
     * @param status Статус лога (например, "INFO", "DEBUG", "ERROR")
     * @param info   Информационное сообщение лога
     * @return HTTP запрос или null, если процесс не инициализирован или не активен
     * @throws ExceptionLoggerWork если произошла ошибка сериализации JSON
     */
    private HttpRequest createRequestSendLog(String status,
                                             String info) throws ExceptionLoggerWork{
        String excMsg = "Error with send request *send log*:\n\t";
        if (!this.isInitialized()) {
            return null;
        }
        if (!this.isActive()) {
            return null;
        }
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("secureCode", this.secureCode.get());
        requestBody.put("status", status);
        requestBody.put("info", info);
        String jsonBody;
        try {
            jsonBody = toJson(requestBody,
                     excMsg);
        } catch (ExceptionLoggerWork eLW) {
            throw eLW;
        }
        if (this.pathSendLog == null) {
            this.createPathSendLog();
        }
        HttpRequest newRequest = HttpRequest.newBuilder()
                                            .uri(URI.create(this.pathSendLog))
                                            .header("Content-Type", "application/json")
                                            .POST(BodyPublishers.ofString(jsonBody))
                                            .build();
        return newRequest;
    }
    
    /**
     * Формирует URL для инициализации процесса.
     * <p>Формат: {apiUrl}/process</p>
     */
    private void createPathInitProcess() {
        StringBuilder resultString = new StringBuilder();
        resultString.append(this.apiUrl);
        resultString.append("/processes");
        this.pathInitProcess = resultString.toString();
    }
    
    /**
     * Формирует URL для остановки процесса.
     * <p>Формат: {apiUrl}/process/{processId}/stop</p>
     * 
     * @throws IllegalStateException если процесс не инициализирован
     */
    private void createPathStopProcess() {
        StringBuilder resultString = new StringBuilder();
        resultString.append(this.apiUrl);
        resultString.append("/processes/");
        resultString.append(this.processId.get());
        resultString.append("/stop");
        this.pathStopProcess = resultString.toString();
    }
    
    /**
     * Формирует URL для отправки логов.
     * <p>Формат: {apiUrl}/process/{processId}/logs</p>
     * 
     * @throws IllegalStateException если процесс не инициализирован
     */
    private void createPathSendLog() {
        StringBuilder resultString = new StringBuilder();
        resultString.append(this.apiUrl);
        resultString.append("/processes/");
        resultString.append(this.processId.get());
        resultString.append("/logs");
        this.pathSendLog = resultString.toString();
    }
    
    // ==================== ПУБЛИЧНЫЕ МЕТОДЫ ====================
    
    /**
     * Отправляет лог на сервер с таймаутом.
     * 
     * <p>Процесс должен быть предварительно инициализирован через {@link #initProcess()}.</p>
     * 
     * <p>При успешной отправке автоматически обновляется счетчик логов
     * (доступен через {@link #getCountLogProcess()}).</p>
     * 
     * <p><b>Таймаут:</b> Запрос прерывается, если сервер не ответил
     * в течение {@code requestTimeoutMS} миллисекунд.</p>
     * 
     * @param log Объект лога с статусом и сообщением
     * @throws ExceptionLoggerWork если:
     *         <ul>
     *           <li>лог null</li>
     *           <li>процесс не инициализирован</li>
     *           <li>процесс не активен</li>
     *           <li>произошла ошибка отправки</li>
     *           <li>превышен таймаут запроса</li>
     *         </ul>
     * @see SendedLog
     * @see #initProcess()
     * @see #getCountLogProcess()
     */
    public void sendLog(SendedLog log) throws ExceptionLoggerWork {
        if (log == null) {
            throw new ExceptionLoggerWork("Error with send request *send log*:\n\tLog is null");
        }
        
        HttpRequest request = this.createRequestSendLog(log.getStatus(), log.getMsg());
        if (request == null) {
            throw new ExceptionLoggerWork("Error with send request *send log*:\n\t" + 
                "Process is not initialized. Call initProcess() first.");
        }
        
        CompletableFuture<HttpResponse<String>> future = null;
        try {
            future = this.client.sendAsync(request, BodyHandlers.ofString());
            
            HttpResponse<String> response = future.get(requestTimeoutMS,
                                                       TimeUnit.MILLISECONDS);
            
            if (response.statusCode() >= 200 && response.statusCode() < 300) {
                this.parseSendLogResponse(response.body());
            } else {
                throw new ExceptionLoggerWork("Error with send request *send log*:\n\t" +
                    "Unexpected response\n\t" +
                    "Status: " + response.statusCode() + "\n\t" +
                    "Body: " + response.body());
            }
            
        } catch (java.util.concurrent.TimeoutException e) {
            if (future != null) {
                future.cancel(true);
            }
            throw new ExceptionLoggerWork("Error with send request *send log*:\n\t" + 
                                        "Timeout: exceeded " + requestTimeoutMS + "ms");
        } catch (java.util.concurrent.ExecutionException e) {
            throw new ExceptionLoggerWork("Error with send request *send log*:\n\t" + 
                "Execution failed: " + e.getCause().getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ExceptionLoggerWork("Error with send request *send log*:\n\t" + 
                "Request was interrupted");
        }
    }
    
    /**
     * Инициализирует процесс на сервере.
     * 
     * <p>После успешной инициализации становятся доступны:</p>
     * <ul>
     *   <li>ID процесса - {@link #getIdProcess()}</li>
     *   <li>Секретный код - для внутреннего использования</li>
     *   <li>Статус процесса - {@link #getStatusProcess()}</li>
     *   <li>Время создания - {@link #getTimeCreateProcess()}</li>
     * </ul>
     * 
     * <p>Процесс считается активным, если статус равен "Active".</p>
     * 
     * <p><b>Таймаут:</b> Запрос прерывается, если сервер не ответил
     * в течение {@code requestTimeoutMS} миллисекунд.</p>
     * 
     * <p><b>Потокобезопасность:</b> Метод синхронизирован через объект {@code lock}.</p>
     * 
     * @throws ExceptionLoggerWork если:
     *         <ul>
     *           <li>HTTP запрос не инициализирован</li>
     *           <li>произошла ошибка отправки</li>
     *           <li>сервер вернул неожиданный статус</li>
     *           <li>ответ не содержит обязательные поля</li>
     *           <li>превышен таймаут запроса</li>
     *         </ul>
     * @see #getIdProcess()
     * @see #getStatusProcess()
     * @see #getTimeCreateProcess()
     * @see #isActive()
     */
    public void initProcess() throws ExceptionLoggerWork {
        if (this.requestInitProcess == null) {
            throw new ExceptionLoggerWork("Error with send request *init process*:\n\t" + 
                "HttpRequest is not initialized");
        }
        
        CompletableFuture<HttpResponse<String>> future = null;
        try {
            synchronized (this.lock) {
                future = this.client.sendAsync(this.requestInitProcess, BodyHandlers.ofString());
            }
            
            HttpResponse<String> response = future.get(requestTimeoutMS,
                                                       TimeUnit.MILLISECONDS);
            
            if (response.statusCode() == WebLogger.RESPONSE_STATUS_CODE_CREATED || 
                response.statusCode() == WebLogger.RESPONSE_STATUS_CODE_OK) {
                this.parseInitProcessResponse(response.body());
                this.createRequestStopProcess();
            } else {
                throw new ExceptionLoggerWork("Error with send request *init process*:\n\t" +
                    "Unexpected response\n\t" +
                    "Status: " + response.statusCode() + "\n\t" +
                    "Body: " + response.body());
            }
            
        } catch (java.util.concurrent.TimeoutException e) {
            if (future != null) {
                future.cancel(true);
            }
            throw new ExceptionLoggerWork("Error with send request *init process*:\n\t" + 
                "Timeout: exceeded " + requestTimeoutMS + "ms");
        } catch (java.util.concurrent.ExecutionException e) {
            throw new ExceptionLoggerWork("Error with send request *init process*:\n\t" + 
                "Execution failed: " + e.getCause().getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ExceptionLoggerWork("Error with send request *init process*:\n\t" + 
                "Request was interrupted");
        }
    }
    
    /**
     * Останавливает процесс на сервере.
     * 
     * <p>После успешной остановки:</p>
     * <ul>
     *   <li>Статус процесса изменяется на "Stopped" - {@link #getStatusProcess()}</li>
     *   <li>Устанавливается время завершения - {@link #getTimeFinishProcess()}</li>
     * </ul>
     * 
     * <p><b>Таймаут:</b> Запрос прерывается, если сервер не ответил
     * в течение {@code requestTimeoutMS} миллисекунд.</p>
     * 
     * <p><b>Потокобезопасность:</b> Метод синхронизирован через объект {@code lock}.</p>
     * 
     * @throws ExceptionLoggerWork если:
     *         <ul>
     *           <li>процесс не инициализирован</li>
     *           <li>HTTP запрос не инициализирован</li>
     *           <li>произошла ошибка отправки</li>
     *           <li>сервер вернул неожиданный статус</li>
     *           <li>ответ не содержит обязательные поля</li>
     *           <li>превышен таймаут запроса</li>
     *         </ul>
     * @see #getStatusProcess()
     * @see #getTimeFinishProcess()
     */
    public void stopProcess() throws ExceptionLoggerWork {
        if (this.requestStopProcess == null) {
            throw new ExceptionLoggerWork("Error with send request *stop process*:\n\t" + 
                "Process is not initialized. Call initProcess() first.");
        }
        
        CompletableFuture<HttpResponse<String>> future = null;
        try {
            synchronized (this.lock) {
                future = this.client.sendAsync(this.requestStopProcess, BodyHandlers.ofString());
            }
            
            HttpResponse<String> response = future.get(requestTimeoutMS,
                                                       TimeUnit.MILLISECONDS);
            
            if (response.statusCode() == WebLogger.RESPONSE_STATUS_CODE_OK) {
                this.parseStopProcessResponse(response.body());
            } else {
                throw new ExceptionLoggerWork("Error with send request *stop process*:\n\t" +
                    "Unexpected response\n\t" +
                    "Status: " + response.statusCode() + "\n\t" +
                    "Body: " + response.body());
            }
            
        } catch (java.util.concurrent.TimeoutException e) {
            if (future != null) {
                future.cancel(true);
            }
            throw new ExceptionLoggerWork("Error with send request *stop process*:\n\t" + 
                "Timeout: exceeded " + requestTimeoutMS + "ms");
        } catch (java.util.concurrent.ExecutionException e) {
            throw new ExceptionLoggerWork("Error with send request *stop process*:\n\t" + 
                "Execution failed: " + e.getCause().getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ExceptionLoggerWork("Error with send request *stop process*:\n\t" + 
                "Request was interrupted");
        }
    }
    
    // ==================== ГЕТТЕРЫ ====================
    
    /**
     * Возвращает имя процесса.
     * 
     * <p>Это значение устанавливается при создании клиента и не может быть изменено.</p>
     * 
     * @return Имя процесса (например, "billing-service")
     */
    public String getNameProcess() {
        return this.nameProcess;
    }
    
    /**
     * Возвращает идентификатор процесса.
     * 
     * <p>Доступен только после успешной инициализации через {@link #initProcess()}.</p>
     * 
     * @return ID процесса или null, если процесс не инициализирован
     * @see #initProcess()
     * @see #isInitialized()
     */
    public String getIdProcess(){
        return this.processId.get();
    }
    
    /**
     * Возвращает общее количество успешно отправленных логов.
     * 
     * <p>Счетчик автоматически обновляется после каждой успешной отправки.</p>
     * <p><b>Примечание:</b> В текущей реализации к полученному значению добавляется 1.</p>
     * 
     * @return Количество отправленных логов
     * @see #sendLog(SendedLog)
     */
    public int getCountLogProcess() {
        return this.countLog.get();
    }
    
    /**
     * Возвращает время создания процесса.
     * 
     * <p>Формат времени: ISO-8601 (например, "2024-01-15T10:30:45")</p>
     * 
     * @return Время создания в формате ISO-8601 или null, если процесс не инициализирован
     * @see #initProcess()
     * @see #isInitialized()
     */
    public String getTimeCreateProcess() {
        return this.timeCreate.get();
    }
    
    /**
     * Возвращает время завершения процесса.
     * 
     * <p>Формат времени: ISO-8601 (например, "2024-01-15T10:35:00")</p>
     * 
     * @return Время завершения в формате ISO-8601 или null, если процесс не остановлен
     * @see #stopProcess()
     */
    public String getTimeFinishProcess() {
        return this.timeFinish.get();
    }
    
    /**
     * Возвращает текущий статус процесса.
     * 
     * <p>Возможные значения:</p>
     * <ul>
     *   <li><b>"Active"</b> - процесс активен и готов к приему логов</li>
     *   <li><b>"Running"</b> - процесс выполняется (не используется в текущей версии)</li>
     *   <li><b>"Stopped"</b> - процесс остановлен</li>
     *   <li><b>null</b> - процесс не инициализирован</li>
     * </ul>
     * 
     * @return Статус процесса или null, если процесс не инициализирован
     * @see #isActive()
     * @see #isInitialized()
     */
    public String getStatusProcess () {
        return this.statusProcess.get();
    }
    
    
    /**
     * Возвращает базовый URL API сервера.
     * 
     * <p>Этот URL используется для формирования всех запросов к REST API.
     * Устанавливается при создании экземпляра WebLogger и не может быть изменен.</p>
     * 
     * <p><b>Пример формата:</b> http://localhost:8080/api</p>
     * 
     * @return Базовый URL API сервера
     * @see #WebLogger(String, String, String, Duration, long)
     */
    public String getApiUrl() {
        return this.apiUrl;
    }

    /**
     * Возвращает уникальный секретный код доступа к процессу.
     * 
     * <p>Этот код выдается сервером при успешной инициализации процесса
     * и используется для аутентификации при отправке логов и остановке процесса.</p>
     * 
     * <p><b>Важно:</b> Метод возвращает null, если процесс еще не инициализирован
     * или инициализация завершилась с ошибкой.</p>
     * 
     * <p><b>Пример формата:</b> "550e8400-e29b-41d4-a716-446655440000"</p>
     * 
     * @return Секретный код доступа или null, если процесс не инициализирован
     * @see #initProcess()
     * @see #isInitialized()
     */
    public String getSecureCode() {
        return this.secureCode.get();
    }

     /**
     * Возвращает уникальный имя процесса остановленное в параметре owner конструктора.
     * @see #WebLogger()
     */
    public String getOwner() {
        return this.owner;
    }
    /**
     * Проверяет, инициализирован ли процесс на сервере.
     * 
     * <p>Процесс считается инициализированным, если получены ID и секретный код.</p>
     * 
     * @return true, если процесс инициализирован, иначе false
     * @see #initProcess()
     * @see #getIdProcess()
     */
    public boolean isInitialized() {
        if (this.processId.get() != null && this.secureCode.get() != null) {
            return true;
        }
        return false;
    }
    
    /**
     * Проверяет, активен ли процесс.
     * 
     * <p>Процесс считается активным, если его статус равен "Active".</p>
     * 
     * <p>Активный процесс может принимать логи через {@link #sendLog(SendedLog)}.</p>
     * 
     * @return true, если процесс активен, иначе false
     * @see #getStatusProcess()
     * @see #sendLog(SendedLog)
     */
    public boolean isActive() {
        if (this.statusProcess.get() == null) {
            return false;
        }
        if (this.statusProcess.get().equals("Active")) {
            return true;
        }
        return false;
    }
    
    // ==================== КОНСТРУКТОРЫ ====================
    
    /**
     * Создает экземпляр WebLogger с настройками по умолчанию.
     * 
     * <p>Используются следующие настройки по умолчанию:</p>
     * <ul>
     *   <li><b>API URL:</b> http://localhost:8080/api</li>
     *   <li><b>Таймаут подключения:</b> 1 секунда</li>
     *   <li><b>Таймаут запроса:</b> 50 мс</li>
     * </ul>
     * 
     * <p><b>Пример использования:</b></p>
     * <pre>
     * WebLogger logger = new WebLogger("admin@company.com", "billing-service");
     * </pre>
     * 
     * @param owner        Владелец процесса (например, "admin@company.com")
     * @param nameProcess  Имя процесса (например, "billing-service")
     * @throws ExceptionLoggerWork если параметры невалидны:
     *         <ul>
     *           <li>Имя процесса null или пустое</li>
     *           <li>Имя процесса длиннее 50 символов</li>
     *           <li>Владелец null или пустой</li>
     *           <li>Владелец длиннее 50 символов</li>
     *         </ul>
     */
    public WebLogger(String owner,
                     String nameProcess) throws ExceptionLoggerWork {
        this.owner = owner;
        this.nameProcess = nameProcess;
        this.apiUrl = WebLogger.DEFAULT_API_BASE;
        this.connectTimeout = WebLogger.DEFAULT_CONNECT_TIMEOUT;
        this.requestTimeoutMS = WebLogger.DEFAULT_REQUEST_TIMEOUT_MS;
        try {
            isValidInData();
        }
        catch (ExceptionLoggerWork excLW) {
            throw excLW;
        }
        
        synchronized (this.lock) {
            this.client = HttpClient.newBuilder()
                                .version(HttpClient.Version.HTTP_1_1)
                                .connectTimeout(this.connectTimeout)
                                .build();
            this.createRequestInitProcess();
        }
    }
    
    /**
     * Создает экземпляр WebLogger с пользовательскими настройками.
     * 
     * <p>Позволяет полностью настроить клиент под конкретные требования.</p>
     * 
     * <p><b>Пример использования:</b></p>
     * <pre>
     * WebLogger logger = new WebLogger(
     *     "http://custom-server.com/api",  // URL API
     *     "admin@company.com",             // Владелец
     *     "billing-service",               // Имя процесса
     *     Duration.ofSeconds(2),           // Таймаут подключения
     *     100                              // Таймаут запроса в мс
     * );
     * </pre>
     * 
     * @param apiBaseApi       Базовый URL API сервера (например, "http://custom-server.com/api")
     * @param owner            Владелец процесса (например, "admin@company.com")
     * @param nameProcess      Имя процесса (например, "billing-service")
     * @param connectTimeout   Таймаут установки TCP соединения
     * @param requestTimeoutMS Таймаут выполнения HTTP запроса в миллисекундах
     * @throws ExceptionLoggerWork если параметры невалидны:
     *         <ul>
     *           <li>Имя процесса null или пустое</li>
     *           <li>Имя процесса длиннее 50 символов</li>
     *           <li>Владелец null или пустой</li>
     *           <li>Владелец длиннее 50 символов</li>
     *           <li>URL API null или пустой (если отличается от дефолтного)</li>
     *           <li>Таймаут запроса {@code <= 0} (если отличается от дефолтного)</li>
     *         </ul>
     */
    public WebLogger(String apiBaseApi, 
                     String owner,
                     String nameProcess,
                     Duration connectTimeout,
                     long requestTimeoutMS) throws ExceptionLoggerWork {        
        this.nameProcess = nameProcess;
        this.owner = owner;
        this.apiUrl = apiBaseApi;
        this.requestTimeoutMS = requestTimeoutMS;
        try {
            isValidInData();
        }
        catch (ExceptionLoggerWork excLW) {
            throw excLW;
        }
        this.connectTimeout = connectTimeout;
        
        synchronized (this.lock) {
            this.client = HttpClient.newBuilder()
                                .version(HttpClient.Version.HTTP_1_1)
                                .connectTimeout(this.connectTimeout)
                                .build();
            this.createRequestInitProcess();
        }
    }
    
    // ==================== ЗАКРЫТИЕ РЕСУРСОВ ====================
    
    /**
     * Закрывает клиент и освобождает ресурсы.
     * 
     * <p>Если процесс активен, он будет автоматически остановлен.</p>
     * 
     * <p>Рекомендуется использовать try-with-resources для автоматического закрытия:</p>
     * <pre>
     * try (WebLogger logger = new WebLogger("admin@company.com", "billing-service")) {
     *     logger.initProcess();
     *     logger.sendLog(new SendedLog("INFO", "Test"));
     * }
     * </pre>
     * 
     * <p>Ошибки, возникающие при остановке процесса, игнорируются,
     * так как закрытие ресурсов имеет более высокий приоритет.</p>
     */
    @Override
    public void close() {
        try {
            if (isActive()) {
                stopProcess();
            }
        }
        catch (ExceptionLoggerWork eLW) {
            //
        }
    }
}