/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.weblogger;

import java.time.LocalDateTime;

/**
 * <h1>ExceptionLoggerWork</h1>
 * <p>
 * Исключение, выбрасываемое при ошибках работы WebLogger клиента.
 * Используется во всех методах класса {@link WebLogger} для обработки
 * ошибок HTTP-запросов, парсинга JSON и таймаутов.
 * </p>
 * 
 * <p>В отличие от стандартных исключений, содержит:</p>
 * <ul>
 *   <li><b>Время возникновения</b> - точная метка времени ошибки</li>
 *   <li><b>Сообщение об ошибке</b> - детальное описание проблемы</li>
 * </ul>
 * 
 * <h2>Пример использования:</h2>
 * <pre>
 * try (WebLogger logger = new WebLogger("admin@company.com", "billing-service")) {
 *     logger.initProcess();
 *     logger.sendLog(new SendedLog("Test message", "INFO"));
 * } catch (ExceptionLoggerWork e) {
 *     System.err.println("Error occurred at: " + e.getTime());
 *     System.err.println("Error message: " + e.getMsg());
 *     // Вывод: Error occurred at: 2024-01-15T10:35:20.456
 *     //         Error message: Timeout: exceeded 50ms
 * }
 * </pre>
 * 
 * <h2>Типичные сценарии возникновения:</h2>
 * <ul>
 *   <li>Таймаут выполнения HTTP запроса</li>
 *   <li>Ошибка сериализации JSON</li>
 *   <li>Ошибка парсинга JSON ответа</li>
 *   <li>Неожиданный HTTP статус ответа</li>
 *   <li>Ошибка соединения с сервером</li>
 *   <li>Процесс не инициализирован при попытке отправки лога</li>
 *   <li>Отсутствие обязательных полей в ответе сервера</li>
 * </ul>
 * 
 * <h2>Связь с другими классами:</h2>
 * <ul>
 *   <li>Используется в {@link WebLogger} - основной класс клиента</li>
 *   <li>Не используется в {@link SendedLog} - там используется {@link ExceptionInitLog}</li>
 * </ul>
 * 
 * @author admin_
 * @version 1.0
 * @see WebLogger
 * @see ExceptionInitLog
 * @see SendedLog
 */
public class ExceptionLoggerWork extends Exception {
    
    /**
     * Время возникновения ошибки.
     * Фиксируется в момент создания исключения.
     */
    private final LocalDateTime timeErr;
    
    /**
     * Сообщение об ошибке.
     * Содержит детальное описание проблемы с контекстом выполнения.
     */
    private final String msg;
    
    /**
     * Создает исключение с указанным сообщением об ошибке.
     * Время ошибки фиксируется автоматически в момент создания.
     * 
     * @param msgException Детальное описание ошибки с контекстом выполнения
     */
    public ExceptionLoggerWork(String msgException) {
        timeErr = LocalDateTime.now();
        msg = msgException;
    }
    
    /**
     * Возвращает время возникновения ошибки в формате ISO-8601.
     * 
     * <p>Пример формата: "2024-01-15T10:35:20.456789123"</p>
     * 
     * @return Время ошибки в формате ISO-8601
     */
    public String getTime(){
        return timeErr.toString();
    }
    
    /**
     * Возвращает сообщение об ошибке.
     * 
     * <p>Сообщение содержит детальную информацию о проблеме,
     * включая контекст выполнения и причину ошибки.</p>
     * 
     * @return Детальное описание ошибки
     */
    public String getMsg() {
        return msg;
    }
}