/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.weblogger;

import java.time.LocalDateTime;

/**
 * <h1>ExceptionInitLog</h1>
 * <p>
 * Исключение, выбрасываемое при ошибках валидации параметров лога.
 * Используется в классе {@link SendedLog} для проверки корректности
 * сообщения и статуса перед созданием объекта.
 * </p>
 * 
 * <p>В отличие от стандартных исключений, содержит:</p>
 * <ul>
 *   <li><b>Время возникновения</b> - точная метка времени ошибки</li>
 *   <li><b>Сообщение об ошибке</b> - детальное описание проблемы</li>
 * </ul>
 * 
 * <h2>Пример использования:</h2>
 * <pre>
 * try {
 *     SendedLog log = new SendedLog("", "INFO");
 * } catch (ExceptionInitLog e) {
 *     System.err.println("Validation error at " + e.getTime());
 *     System.err.println("Message: " + e.getMsg());
 *     // Вывод: Validation error at 2024-01-15T10:30:45.123
 *     //         Message: Error input param *msg*: string is empty or null
 * }
 * </pre>
 * 
 * <h2>Типичные сценарии возникновения:</h2>
 * <ul>
 *   <li>Сообщение лога null или пустое</li>
 *   <li>Сообщение лога превышает 200 символов</li>
 *   <li>Статус лога null или пустой</li>
 *   <li>Статус лога не соответствует допустимым значениям</li>
 *   <li>Статус лога превышает 5 символов</li>
 * </ul>
 * 
 * @author admin_
 * @version 1.0
 * @see SendedLog
 * @see WebLogger
 * @see ExceptionLoggerWork
 */
public class ExceptionInitLog extends Exception {
    
    /**
     * Время возникновения ошибки.
     * Фиксируется в момент создания исключения.
     */
    private final LocalDateTime timeErr;
    
    /**
     * Сообщение об ошибке.
     * Содержит детальное описание проблемы.
     */
    private final String msg;
    
    /**
     * Создает исключение с указанным сообщением об ошибке.
     * Время ошибки фиксируется автоматически в момент создания.
     * 
     * @param msg Детальное описание ошибки валидации
     */
    public ExceptionInitLog(String msg){
        this.msg = msg;
        timeErr = LocalDateTime.now();
    }
    
    /**
     * Возвращает сообщение об ошибке.
     * 
     * @return Детальное описание ошибки
     */
    public String getMsg() {
        return msg;
    }
    
    /**
     * Возвращает время возникновения ошибки в формате ISO-8601.
     * 
     * <p>Пример формата: "2024-01-15T10:30:45.123456789"</p>
     * 
     * @return Время ошибки в формате ISO-8601
     */
    public String getTime() {
        return timeErr.toString();
    }
}