/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.weblogger;

/**
 * <h1>SendedLog</h1>
 * <p>
 * Класс, представляющий лог для отправки на сервер WebLogger.
 * Содержит статус лога и информационное сообщение с валидацией входных параметров.
 * </p>
 * 
 * <h2>Допустимые статусы:</h2>
 * <ul>
 *   <li><b>FATAL</b> - фатальная ошибка</li>
 *   <li><b>ERROR</b> - ошибка (не используется в текущей версии)</li>
 *   <li><b>WARN</b> - предупреждение</li>
 *   <li><b>INFO</b> - информационное сообщение</li>
 *   <li><b>DEBUG</b> - отладочное сообщение</li>
 *   <li><b>TRACE</b> - трассировочное сообщение</li>
 * </ul>
 * 
 * <h2>Ограничения:</h2>
 * <ul>
 *   <li>Максимальная длина сообщения: 200 символов</li>
 *   <li>Максимальная длина статуса: 5 символов</li>
 *   <li>Статус должен быть одним из допустимых значений</li>
 * </ul>
 * 
 * <h2>Пример использования:</h2>
 * <pre>
 * try {
 *     SendedLog log = new SendedLog("Application started successfully", "INFO");
 *     System.out.println("Status: " + log.getStatus());
 *     System.out.println("Message: " + log.getMsg());
 * } catch (ExceptionInitLog e) {
 *     System.err.println("Invalid log: " + e.getMessage());
 * }
 * </pre>
 * 
 * @author admin_
 * @version 1.0
 * @see WebLogger
 * @see ExceptionInitLog
 */
public class SendedLog {
    
    // ==================== КОНСТАНТЫ ====================
    
    /**
     * Массив допустимых статусов лога.
     */
    private static final String[] CORRECTNESS_STATUSES = {"FATAL", "INFO", "WARN", "DEBUG", "TRACE"};
    
    /**
     * Максимальная длина сообщения в символах.
     */
    private static final int MAX_SIZE_MSG = 200;
    
    /**
     * Максимальная длина статуса в символах.
     */
    private static final int MAX_SIZE_LOG = 5;
    
    // ==================== ПОЛЯ ====================
    
    /**
     * Информационное сообщение лога.
     * Не может быть null, пустым или длиннее 200 символов.
     */
    private final String msg;
    
    /**
     * Статус лога.
     * Должен быть одним из допустимых значений: FATAL, INFO, WARN, DEBUG, TRACE.
     */
    private final String status;
    
    // ==================== ПРИВАТНЫЕ МЕТОДЫ ====================
    
    /**
     * Формирует строку со списком допустимых статусов для сообщений об ошибках.
     * 
     * @return Строка со всеми допустимыми статусами через запятую
     */
    private String getCombinedValidStatuses(){
        StringBuilder resultString = new StringBuilder("Valid statuses: ");
        for (int i = 0; i < CORRECTNESS_STATUSES.length; i++) {
            resultString.append(CORRECTNESS_STATUSES[i]);
            if (i < CORRECTNESS_STATUSES.length - 1) {
                resultString.append(", ");
            }
        }
        return resultString.toString();
    }
    
    /**
     * Проверяет корректность входных данных для создания лога.
     * 
     * <p>Валидируются следующие параметры:</p>
     * <ul>
     *   <li>Сообщение - не null, не пустое, длина ≤ 200 символов</li>
     *   <li>Статус - не null, не пустой, длина ≤ 5 символов</li>
     *   <li>Статус - должен быть одним из допустимых значений</li>
     * </ul>
     * 
     * @throws ExceptionInitLog если какой-либо параметр невалиден
     */
    private void isValidInData() throws ExceptionInitLog{
        if (msg == null || msg.isEmpty()) {
            throw new ExceptionInitLog("Error input param *msg*: string is empty or null");
        }
        if (msg.length() > MAX_SIZE_MSG) {
            throw new ExceptionInitLog("Error input param *msg*: string's length is more " + Integer.toString(MAX_SIZE_MSG));
        }
        if (status == null || status.isEmpty()) {
            throw new ExceptionInitLog("Error input param *status*: string's length is empty or null");
        }
        if (status.length() > MAX_SIZE_LOG) {
            throw new ExceptionInitLog("Error input param *status*: uncorrect Status. " + getCombinedValidStatuses());
        }
        boolean flagFind = false;
        for (int i = 0; i < CORRECTNESS_STATUSES.length; i++) {
            if (status.equals(CORRECTNESS_STATUSES[i])) {
                flagFind = true;
                break;
            }
        }
        if (flagFind == false) {
            throw new ExceptionInitLog("Error input param *status*: uncorrect Status. " + getCombinedValidStatuses());
        }
    }
    
    // ==================== КОНСТРУКТОР ====================
    
    /**
     * Создает объект лога с указанным сообщением и статусом.
     * 
     * <p>Выполняется валидация входных параметров.</p>
     * 
     * @param msg    Информационное сообщение (не null, не пустое, ≤ 200 символов)
     * @param status Статус лога (должен быть одним из: FATAL, INFO, WARN, DEBUG, TRACE)
     * @throws ExceptionInitLog если параметры невалидны:
     *         <ul>
     *           <li>Сообщение null или пустое</li>
     *           <li>Сообщение длиннее 200 символов</li>
     *           <li>Статус null или пустой</li>
     *           <li>Статус длиннее 5 символов</li>
     *           <li>Статус не входит в список допустимых</li>
     *         </ul>
     */
    public SendedLog(String msg,
                   String status) throws ExceptionInitLog {
       this.msg = msg;
       this.status = status;
       try {
           isValidInData();
       }
       catch (ExceptionInitLog exc) {
           throw exc;
       }
    }
    
    // ==================== ГЕТТЕРЫ ====================
    
    /**
     * Возвращает информационное сообщение лога.
     * 
     * @return Сообщение лога
     */
    public String getMsg() {
        return msg;
    }
    
    /**
     * Возвращает статус лога.
     * 
     * @return Статус лога (FATAL, INFO, WARN, DEBUG, TRACE)
     */
    public String getStatus() {
        return status;
    }
}